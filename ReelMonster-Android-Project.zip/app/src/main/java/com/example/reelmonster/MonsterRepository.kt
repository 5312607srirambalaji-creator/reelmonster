package com.example.reelmonster

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.*

class MonsterRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("reel_monster_stats", Context.MODE_PRIVATE)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun getTodayKey(): String = dateFormat.format(Date())

    fun getTodayCount(): Int {
        return prefs.getInt(getTodayKey(), 0)
    }

    fun incrementTodayCount(): Int {
        val key = getTodayKey()
        val current = prefs.getInt(key, 0) + 1
        prefs.edit().putInt(key, current).apply()
        return current
    }

    fun getLast7Days(): List<Pair<String, Int>> {
        val list = mutableListOf<Pair<String, Int>>()
        for (i in 6 downTo 0) {
            val date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val key = dateFormat.format(date.time)
            val dayLabel = SimpleDateFormat("EEE", Locale.getDefault()).format(date.time)
            list.add(Pair(dayLabel, prefs.getInt(key, 0)))
        }
        return list
    }

    fun getTimeLostFormatted(count: Int): String {
        val totalMinutes = (count * 30) / 60
        val hours = totalMinutes / 60
        val mins = totalMinutes % 60
        return when {
            hours > 0 -> "${hours}h ${mins}m lost"
            else -> "${mins}m lost"
        }
    }

    fun getMonsterComment(count: Int): String = when {
        count == 0 -> "I'm hungry for doom-scrolling!"
        count in 1..10 -> "Snack time! Just warming up."
        count in 11..30 -> "Yum! Your evening tastes great."
        count in 31..60 -> "Mmm, delicious brain fog!"
        count in 61..100 -> "Burp. Your homework says hi."
        else -> "I'm huge now! You've completely lost track of time."
    }
}

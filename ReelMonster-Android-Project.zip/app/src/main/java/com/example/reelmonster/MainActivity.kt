package com.example.reelmonster

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var repo: MonsterRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = MonsterRepository(this)

        findViewById<Button>(R.id.btnPermissions).setOnClickListener {
            checkAndPromptPermissions()
        }
    }

    override fun onResume() {
        super.onResume()
        updateDashboard()
    }

    private fun updateDashboard() {
        val todayCount = repo.getTodayCount()
        findViewById<TextView>(R.id.tvTodayCount).text = todayCount.toString()
        findViewById<TextView>(R.id.tvTimeLost).text = "reels · ${repo.getTimeLostFormatted(todayCount)}"
        findViewById<TextView>(R.id.tvInsideMonsterNote).text = repo.getMonsterComment(todayCount)

        renderChart()
    }

    private fun renderChart() {
        val container = findViewById<LinearLayout>(R.id.chartBarsContainer)
        container.removeAllViews()

        val history = repo.getLast7Days()
        val maxVal = (history.maxOfOrNull { it.second } ?: 1).coerceAtLeast(10)

        for (item in history) {
            val col = layoutInflater.inflate(R.layout.item_chart_bar, container, false)
            val barView = col.findViewById<android.view.View>(R.id.barFill)
            val labelView = col.findViewById<TextView>(R.id.tvBarDay)

            val heightRatio = item.second.toFloat() / maxVal.toFloat()
            val heightPx = (heightRatio * 200).coerceAtLeast(12f).toInt()

            val lp = barView.layoutParams
            lp.height = heightPx
            barView.layoutParams = lp

            labelView.text = item.first
            container.addView(col)
        }
    }

    private fun checkAndPromptPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }

        val accessibilityIntent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(accessibilityIntent)

        startService(Intent(this, MonsterOverlayService::class.java))
    }
}

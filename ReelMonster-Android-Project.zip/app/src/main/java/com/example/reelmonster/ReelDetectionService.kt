package com.example.reelmonster

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ReelDetectionService : AccessibilityService() {

    private var lastScrollTime = 0L
    private val scrollThresholdMs = 850L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return
        val isTargetApp = pkg == "com.instagram.android" || pkg == "com.google.android.youtube"

        val visIntent = Intent(this, MonsterOverlayService::class.java).apply {
            putExtra("ACTION", "SET_VISIBILITY")
            putExtra("VISIBLE", isTargetApp)
        }
        startService(visIntent)

        if (!isTargetApp) return

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {

            val rootNode = rootInActiveWindow ?: return
            if (isInReelOrShortsContext(rootNode, pkg)) {
                val now = System.currentTimeMillis()
                if (now - lastScrollTime > scrollThresholdMs) {
                    lastScrollTime = now
                    notifyReelViewed()
                }
            }
        }
    }

    private fun isInReelOrShortsContext(node: AccessibilityNodeInfo, pkg: String): Boolean {
        val targetIds = if (pkg.contains("instagram")) {
            listOf("clips_video_container", "reel_viewer_root", "view_pager")
        } else {
            listOf("shorts_container", "reel_player_page", "view_pager2")
        }

        for (id in targetIds) {
            val matches = node.findAccessibilityNodeInfosByViewId("$pkg:id/$id")
            if (matches.isNotEmpty()) return true
        }
        return false
    }

    private fun notifyReelViewed() {
        val updateIntent = Intent(this, MonsterOverlayService::class.java).apply {
            putExtra("ACTION", "UPDATE_COUNT")
        }
        startService(updateIntent)
    }

    override fun onInterrupt() {}
}

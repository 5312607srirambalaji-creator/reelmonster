package com.example.reelmonster

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.view.isVisible

class MonsterOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var repository: MonsterRepository

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        repository = MonsterRepository(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupOverlay()
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun setupOverlay() {
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_monster, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 250
        }

        val monsterFace = floatingView.findViewById<FrameLayout>(R.id.monsterFace)
        val tvBadge = floatingView.findViewById<TextView>(R.id.tvCountBadge)
        val tvBubble = floatingView.findViewById<TextView>(R.id.tvSpeechBubble)

        updateView(tvBadge, tvBubble, monsterFace, repository.getTodayCount())

        monsterFace.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val diffX = Math.abs(event.rawX - initialTouchX)
                    val diffY = Math.abs(event.rawY - initialTouchY)
                    if (diffX < 12 && diffY < 12) {
                        val count = repository.incrementTodayCount()
                        updateView(tvBadge, tvBubble, monsterFace, count)
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(floatingView, params)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            val action = it.getStringExtra("ACTION")
            val badge = floatingView.findViewById<TextView>(R.id.tvCountBadge)
            val bubble = floatingView.findViewById<TextView>(R.id.tvSpeechBubble)
            val face = floatingView.findViewById<FrameLayout>(R.id.monsterFace)

            when (action) {
                "UPDATE_COUNT" -> {
                    val newCount = repository.incrementTodayCount()
                    updateView(badge, bubble, face, newCount)
                }
                "SET_VISIBILITY" -> {
                    val visible = it.getBooleanExtra("VISIBLE", true)
                    floatingView.isVisible = visible
                }
                "SYNC" -> {
                    updateView(badge, bubble, face, repository.getTodayCount())
                }
            }
        }
        return START_STICKY
    }

    private fun updateView(badge: TextView, bubble: TextView, face: View, count: Int) {
        badge.text = count.toString()
        bubble.text = repository.getMonsterComment(count)
        val scale = 1.0f + (count.coerceAtMost(120) / 280f)
        face.scaleX = scale
        face.scaleY = scale
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
    }
}
